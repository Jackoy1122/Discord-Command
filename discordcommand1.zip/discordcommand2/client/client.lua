------------------------------------------------------
-- DONT CHANGE IF YOU DON'T KNOW WHAT YOUR DOING --
------------------------------------------------------

RegisterCommand('discord', function()
    TriggerEvent('chat:addMessage', {
        color = {255, 0, 0},
        multline = true,
        args = {'[SERVERNAME] come check out our discord at DISCORDLINK'}
})
end)